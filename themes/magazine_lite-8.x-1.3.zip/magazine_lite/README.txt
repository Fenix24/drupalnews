Magazine Lite 

Please visit https://github.com/morethanthemes/magazine-lite
